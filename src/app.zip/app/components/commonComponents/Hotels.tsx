'use client'

import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useParams } from "next/navigation"

interface Hotel {
  slug: string
  name: string
  image?: string
  rating?: number
  facilitiesN?: string[]
}

interface Icons {
  [key: string]: string
}

export default function HotelsList() {
  const { category, id } = useParams() as { category?: string; id?: string }
  const [hotels, setHotels] = useState<Hotel[]>([])
  const [icons, setIcons] = useState<Icons>({})
  const [filter, setFilter] = useState("all")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!category || !id) return

    setLoading(true)
    setError(null)

    fetch(`/api/${category}/${id}`)
      .then((res) => {
        if (!res.ok) throw new Error(`Failed to load hotels: ${res.statusText}`)
        return res.json()
      })
      .then((data) => {
        if (Array.isArray(data.hotels)) {
          setHotels(data.hotels)
        } else {
          setError("Hotels data format is invalid")
        }
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false))

    fetch(`/api/hotel-icons`)
      .then((res) => res.json())
      .then((data) => setIcons(data))
      .catch(() => {
        /* ignore icon loading */
      })
  }, [category, id])

  const filteredHotels = hotels.filter((hotel) =>
    filter === "all" ? true : hotel.facilitiesN?.includes(filter)
  )

  const filters = ["all", ...Object.keys(icons)]

  if (loading) return <p className="text-center">Loading hotels...</p>
  if (error) return <p className="text-center text-red-600">{error}</p>
  if (filteredHotels.length === 0)
    return <p className="text-center">No hotels found for selected filter.</p>

  return (
    <section id="hotels" className="mb-5 max-w-5xl mx-auto px-4">
      <h2 className="section-title mb-4 text-2xl font-semibold">Nearby Hotels</h2>

      <div className="flex flex-wrap gap-3 mb-6">
        {filters.map((f) => (
          <button
            key={f}
            className={`px-4 py-1 rounded border ${
              filter === f ? "bg-black text-white" : "bg-gray-100 text-gray-800"
            }`}
            onClick={() => setFilter(f)}
          >
            {f === "all" ? "All" : f.toUpperCase()}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredHotels.map((hotel) => (
          <Link
            key={hotel.slug}
            href={`/${category}/${id}/${hotel.slug}`}
            className="block border rounded-lg shadow hover:shadow-lg transition p-4"
          >
            {hotel.image && (
              <div className="relative h-48 w-full rounded overflow-hidden mb-3">
                <Image
                  src={hotel.image.startsWith("/") ? hotel.image : `/${hotel.image}`}
                  alt={hotel.name}
                  fill
                  className="object-cover"
                />
              </div>
            )}
            <h3 className="text-lg font-bold mb-1">{hotel.name}</h3>
            {typeof hotel.rating === "number" && (
              <p className="text-yellow-500 mb-2">⭐ {hotel.rating.toFixed(1)}</p>
            )}
            <div className="flex gap-3 text-xl text-gray-600">
              {(hotel.facilitiesN || []).map((facility) => (
                <span key={facility} dangerouslySetInnerHTML={{ __html: icons[facility] || "" }} />
              ))}
            </div>
          </Link>
        ))}
      </div>
    </section>
  )
}
