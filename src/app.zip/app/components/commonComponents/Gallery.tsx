"use client";
import React from "react";
import Image from "next/image";
import SectionTitle from "./SectionTitle";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Autoplay } from "swiper/modules";

import "swiper/css";
import "swiper/css/navigation";

interface GalleryImage {
  src?: string;
  thumb?: string;
  alt?: string;
}

export default function Gallery({ images = [] }: { images?: GalleryImage[] }) {
  if (!images.length) return null;

  return (
    <section id="gallery" className="mb-8">
      <SectionTitle title="Image Gallery" />

      <div className="relative group">
        <Swiper
          modules={[Navigation, Autoplay]}
          spaceBetween={10}
          slidesPerView={1}
          navigation
          loop={true}
          autoplay={{
            delay: 3000,
            disableOnInteraction: false,
            pauseOnMouseEnter: true,
          }}
          breakpoints={{
            640: { slidesPerView: 1 },
            768: { slidesPerView: 2 },
            1024: { slidesPerView: 4 },
          }}
          className="gallery-swiper py-2"
        >
          {images.map((img, idx) => (
            <SwiperSlide key={idx} className="!h-auto">
              <div className="relative w-full h-48 rounded overflow-hidden">
                {img.thumb && (
                  <Image
                    src={img.thumb}
                    alt={img.alt || "Gallery Image"}
                    fill
                    className="object-cover"
                  />
                )}
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </section>
  );
}
