// app/components/Footer.js
export default function Footer() {
  return (
    <footer className="text-center py-3 bg-dark text-white mt-5">
      <p>&copy; 2025 Explore Maharashtra. Discover its Beauty & Culture.</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </footer>
  )
}
