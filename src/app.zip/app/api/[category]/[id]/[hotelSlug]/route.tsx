import { NextResponse } from 'next/server'
import path from 'path'
import fs from 'fs/promises'

export async function GET(
  req: Request,
  { params }: { params: Promise<{ category: string; id: string; hotelSlug: string }> }
) {
  const { category, id, hotelSlug } = await params

  try {
    const filePath = path.join(process.cwd(), 'public', 'data', category, id, `${hotelSlug}.json`)
    const content = await fs.readFile(filePath, 'utf8')
    const data = JSON.parse(content)
    return NextResponse.json({ data })
  } catch (err) {
    return NextResponse.json({ error: 'File not found' }, { status: 404 })
  }
}
