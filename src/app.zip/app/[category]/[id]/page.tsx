'use client'

import React, { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'

import Banner from '../../components/commonComponents/Banner'
import Overview from '../../components/commonComponents/Overview'
import Highlights from '../../components/commonComponents/Highlights'
import Geography from '../../components/commonComponents/Geography'
import Activities from '../../components/commonComponents/Activities'
import Attractions from '../../components/commonComponents/Attractions'
import MarineLife from '../../components/commonComponents/MarineLife'
import HowToReach from '../../components/commonComponents/HowToReach'
import Gallery from '../../components/commonComponents/Gallery'
import Hotels from '../../components/commonComponents/Hotels'
import BookingTips from '../../components/commonComponents/BookingTips'

export default function ItemPage() {
  const { category, id } = useParams() as { category?: string; id?: string }
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [view, setView] = useState<'info' | 'hotels'>('info')

  useEffect(() => {
    if (!category || !id) return
    setLoading(true)
    fetch(`/api/${category}/${id}`)
      .then(res => res.json())
      .then(json => setData(json))
      .catch(err => console.error('Failed to fetch data', err))
      .finally(() => setLoading(false))
  }, [category, id])

  if (loading) return <div className="text-center py-10">Loading...</div>
  if (!data) return <div className="text-center py-10 text-warning">Data not found</div>

  return (
    <>
      <Banner
        title={data.title ?? 'No Title'}
        subtitle={data.subtitle ?? ''}
        image={data.bannerImage ?? ''}
        view={view}
        setView={setView}
      />

      <main className="container my-5">
        {view === 'info' && (
          <div id="overViewInfo">
            <Overview content={data.overview ?? 'Overview not available'} />
            {data.highlights?.length > 0 && <Highlights highlights={data.highlights} />}
            {data.geography && <Geography content={data.geography} />}
            {data.activities?.length > 0 && <Activities activities={data.activities} />}
            {data.attractions?.length > 0 && <Attractions items={data.attractions} />}
            {data.marineLife && <MarineLife content={data.marineLife} />}
            {data.gallery?.length > 0 && <Gallery images={data.gallery} />}
            {data.howToReach?.length > 0 && <HowToReach transport={data.howToReach} />}
          </div>
        )}

        {view === 'hotels' && (
          <div id="hotelsList">
            <Hotels />
            {data.bookingTips?.length > 0 && <BookingTips tips={data.bookingTips} />}
          </div>
        )}
      </main>
    </>
  )
}
